"""
agent.py
Cyber Domain and Brand Monitoring AI Agent
Orchestrates the full two-tier scan pipeline with LLM risk synthesis.
"""

from __future__ import annotations
import json
import datetime
from typing import Optional
from . import config, sources, content_check, llm


# ── risk tier mapping ────────────────────────────────────────────────────────
_CLASSIFICATION_TO_RISK = {
    "PHISHING":   "HIGH",
    "SUSPICIOUS": "HIGH",
    "PARKED":     "MEDIUM",
    "LEGITIMATE": "LOW",
    "UNRELATED":  "LOW",
    "UNKNOWN":    "MEDIUM",
}


def _synthesise_risk(
    domain:          str,
    protected_brand: str,
    dns_result:      dict,
    cert_result:     dict,
    content_result:  Optional[dict],
) -> dict:
    """
    Ask the LLM to produce a final risk narrative combining all signals.
    """
    cert_count  = cert_result.get("cert_count", 0)
    cert_recent = cert_result.get("most_recent", "unknown")
    content_cls = (content_result or {}).get("classification", "NOT_FETCHED")
    content_sum = (content_result or {}).get("summary", "Not analysed.")
    indicators  = (content_result or {}).get("indicators", [])

    prompt = f"""You are a senior cybersecurity analyst specialising in
brand protection for financial institutions.

Protected brand:  {protected_brand}
Suspicious domain: {domain}
IP address:       {dns_result.get('ip', 'unknown')}

Certificate Transparency:
  Certificates issued: {cert_count}
  Most recent cert:    {cert_recent}

Content classification: {content_cls}
Content summary: {content_sum}
Indicators found: {', '.join(indicators) if indicators else 'none'}

Synthesise all signals and produce a final risk assessment.
Consider certificate count, recency, content classification,
and whether this represents an active threat to the protected brand.

Respond in this exact JSON format with no other text:
{{
  "risk_tier": "HIGH" | "MEDIUM" | "LOW",
  "risk_score": <integer 1-10>,
  "threat_type": "PHISHING" | "TYPOSQUAT" | "DOMAIN_SQUATTING" | "PARKED" | "LEGITIMATE" | "UNKNOWN",
  "narrative": "two to three sentence plain English risk narrative for a CISO",
  "recommended_actions": ["action1", "action2"],
  "urgency": "IMMEDIATE" | "THIS_WEEK" | "MONITOR" | "NO_ACTION"
}}"""

    result = llm.generate_json(prompt)
    return result


def run_scan(
    protected_brand: Optional[str] = None,
    mode:            str            = "curated",
    max_tier2:       int            = 10,
) -> dict:
    """
    Run a full brand protection scan.

    Args:
        protected_brand: domain to protect (default from config)
        mode: 'curated' (16 TLDs) or 'full' (all IANA TLDs)
        max_tier2: max domains to deep-analyse in Tier 2

    Returns:
        Full scan report as a dict
    """
    brand   = protected_brand or config.PROTECTED_DOMAIN
    started = datetime.datetime.utcnow().isoformat() + "Z"

    print(f"\n{'='*60}")
    print(f"  CYBER DOMAIN AND BRAND MONITORING AI AGENT")
    print(f"  Protected brand: {brand}")
    print(f"  Scan mode:       {mode}")
    print(f"  Started:         {started}")
    print(f"{'='*60}\n")

    # ── TIER 1: DNS sweep ────────────────────────────────────────────────────
    print(f"  [TIER 1] DNS resolution sweep...")
    tier1_results = sources.sweep(brand, mode=mode)
    resolving     = [r for r in tier1_results if r.get("resolves")]
    print(f"  Variants checked: {len(tier1_results)}")
    print(f"  Resolving:        {len(resolving)}")

    if not resolving:
        print(f"\n  No resolving domains found. Scan complete.")
        return {
            "protected_brand": brand,
            "scan_mode":       mode,
            "started":         started,
            "completed":       datetime.datetime.utcnow().isoformat() + "Z",
            "summary": {
                "variants_checked": len(tier1_results),
                "resolving":        0,
                "high_risk":        0,
                "medium_risk":      0,
                "low_risk":         0,
            },
            "findings": [],
        }

    # ── TIER 2: Deep analysis ────────────────────────────────────────────────
    print(f"\n  [TIER 2] Deep analysis (max {max_tier2} domains)...")
    findings = []

    for i, dns_result in enumerate(resolving[:max_tier2], 1):
        domain = dns_result["domain"]
        print(f"\n  [{i}/{min(len(resolving), max_tier2)}] Analysing: {domain}")

        # Certificate Transparency
        print(f"    Checking certificates...")
        cert_result = sources.check_certs(domain)
        cert_count  = cert_result.get("cert_count", 0)
        print(f"    Certificates found: {cert_count}")

        # Content classification (LLM)
        content_result = None
        if cert_count > 0 or dns_result.get("ip"):
            print(f"    Fetching and classifying page content...")
            content_result = content_check.classify(domain, brand)
            print(f"    Classification: {content_result.get('classification', 'UNKNOWN')}")

        # Risk synthesis (LLM)
        print(f"    Synthesising risk...")
        risk = _synthesise_risk(
            domain, brand, dns_result, cert_result, content_result
        )

        # Override risk tier from LLM if content says PHISHING
        if content_result:
            cls = content_result.get("classification", "")
            if cls in ("PHISHING", "SUSPICIOUS") and risk.get("risk_tier") != "HIGH":
                risk["risk_tier"] = "HIGH"

        tier = risk.get("risk_tier", "MEDIUM")
        print(f"    Risk tier: {tier} | Score: {risk.get('risk_score', '?')}/10")

        findings.append({
            "domain":           domain,
            "ip":               dns_result.get("ip", ""),
            "risk_tier":        tier,
            "risk_score":       risk.get("risk_score", 5),
            "threat_type":      risk.get("threat_type", "UNKNOWN"),
            "urgency":          risk.get("urgency", "MONITOR"),
            "narrative":        risk.get("narrative", ""),
            "recommended_actions": risk.get("recommended_actions", []),
            "cert_count":       cert_count,
            "cert_most_recent": cert_result.get("most_recent", ""),
            "content": {
                "fetched":         (content_result or {}).get("fetched", False),
                "classification":  (content_result or {}).get("classification", "NOT_FETCHED"),
                "confidence":      (content_result or {}).get("confidence", ""),
                "indicators":      (content_result or {}).get("indicators", []),
                "summary":         (content_result or {}).get("summary", ""),
                "recommended_action": (content_result or {}).get("recommended_action", "MONITOR"),
            },
        })

    # ── SORT by risk score descending ────────────────────────────────────────
    findings.sort(key=lambda x: x.get("risk_score", 0), reverse=True)

    completed = datetime.datetime.utcnow().isoformat() + "Z"

    high   = sum(1 for f in findings if f["risk_tier"] == "HIGH")
    medium = sum(1 for f in findings if f["risk_tier"] == "MEDIUM")
    low    = sum(1 for f in findings if f["risk_tier"] == "LOW")

    print(f"\n{'='*60}")
    print(f"  SCAN COMPLETE")
    print(f"  High risk:   {high}")
    print(f"  Medium risk: {medium}")
    print(f"  Low risk:    {low}")
    print(f"{'='*60}\n")

    return {
        "protected_brand": brand,
        "scan_mode":       mode,
        "started":         started,
        "completed":       completed,
        "summary": {
            "variants_checked": len(tier1_results),
            "resolving":        len(resolving),
            "analysed":         len(findings),
            "high_risk":        high,
            "medium_risk":      medium,
            "low_risk":         low,
        },
        "findings": findings,
    }
